package com.example.archermind.service2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView textViewService;
    private Button buttonStat,buttonStop;
    public static final int CMD_STOP_SERVICE = 0;
    DataReceiver dataReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewService = findViewById(R.id.textservice);
        buttonStat = findViewById(R.id.buttonstart);
        buttonStop = findViewById(R.id.buttonstop);

        buttonStat.setOnClickListener(buttonClick);
        buttonStop.setOnClickListener(buttonClick);

    }

    private View.OnClickListener buttonClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(v == buttonStat){
                Intent intentService = new Intent(MainActivity.this,MyService.class);
                startService(intentService);
                Log.e("onStartCommand", "onClickListener");
            }else if(v == buttonStop){
                Intent intent = new Intent();
                intent.setAction("AAAAA");
                intent.putExtra("cmd",CMD_STOP_SERVICE);
                sendBroadcast(intent);
            }
        }
    };


    //接受data广播
    private class DataReceiver extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.e("onStartCommand", "接受要更新的数据="+intent.getStringExtra("data"));
            String Date = intent.getStringExtra("data"); //接受data广播
            textViewService.setText(Html.fromHtml("<font color='#0066CC'><u>"+"Service的数据为："+Date+"</font>"));
        }
    }

    @Override
    protected void onStart() {
        dataReceiver = new DataReceiver();
        IntentFilter intentFilter = new IntentFilter();//创建IntentFilter对象
        intentFilter.addAction("AAAAA");
        registerReceiver(dataReceiver,intentFilter);//注册Broadcast Receiver
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(dataReceiver);//取消注册Broadcast Receiver
        super.onStop();
    }
}
