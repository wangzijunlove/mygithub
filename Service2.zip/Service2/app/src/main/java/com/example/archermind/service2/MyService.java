package com.example.archermind.service2;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.IBinder;
import android.util.Log;

import java.util.UUID;

import javax.security.auth.login.LoginException;

public class MyService extends Service {

    CommandReceive cmdReceiver;
    boolean flag;

    @Override
    public void onDestroy() {
        this.unregisterReceiver(cmdReceiver); //取消BroadcastReceiver
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }

    @Override
    public void onRebind(Intent intent) {
        super.onRebind(intent);
    }

    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public void onCreate() {
        cmdReceiver = new CommandReceive();
        flag = true;
        Log.e("onStartCommand", "onCreate");
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
//        Log.e("onStartCommand", "onStartCommand: "+startId+" " + flags );
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("AAAAA");//BBBBB
        registerReceiver(cmdReceiver,intentFilter);  //注册Broadcast Receiver
        doJob(); //调用方法启动线程,发送广播
        Log.e("onStartCommand", "onStartCommand: "+startId+" " + flags );
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }

    @Override
    public IBinder onBind(Intent intent) {

        return null;
    }

    //接受cmd广播
    private class CommandReceive extends BroadcastReceiver{

        @Override
        public void onReceive(Context context, Intent intent) {
            int cmd = intent.getIntExtra("cmd",-1);
            if(cmd == MainActivity.CMD_STOP_SERVICE){ //如果等于0
                flag = false; //停止线程
                stopSelf();  //停止服务
            }
        }
    }

    public void doJob(){
        new Thread(){
            @Override
            public void run() {
                while (flag){//如果等于true执行发送广播
                    try {
                        Thread.sleep(1000);//休眠1秒
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    Log.e("onStartCommand", "run: =" );
                    Intent intent = new Intent();
                    intent.setAction("AAAAA"); //BBBBB
                    intent.putExtra("data", UUID.randomUUID()+"");
                    sendBroadcast(intent);//发送广播名称AAAAA 参数名data
                }
            }
        }.start();
    }

}
