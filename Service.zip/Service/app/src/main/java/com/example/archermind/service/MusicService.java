package com.example.archermind.service;

import android.app.Service;
import android.content.Intent;
import android.content.ServiceConnection;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

public class MusicService extends Service {
    private static String TAG = "MusicService";
    //定于音乐播放器变量
    private MediaPlayer mPlayer;

    //该服务不存在需要被创建时调用，不管startService()还是bindService()都会启动时调用该方法
    @Override
    public void onCreate() {
        Toast.makeText(this,"MusicService onCreate()",Toast.LENGTH_LONG).show();
        Log.e(TAG, "MusicService onCreate: " );

        mPlayer = MediaPlayer.create(getApplicationContext(),R.raw.music);
        //设置可以重复播放
        mPlayer.setLooping(true);
        super.onCreate();
    }

    @Override
    public void onStart(Intent intent, int startId) {
        Toast.makeText(this,"MusicService onStart()",Toast.LENGTH_LONG).show();
        Log.e(TAG, "MusicService onStart: " );

        mPlayer.start();

        super.onStart(intent, startId);
    }

    @Override
    public void onDestroy() {
        Toast.makeText(this, "MusicSevice onDestroy()"
                , Toast.LENGTH_SHORT).show();
        Log.e(TAG, "MusicService onDestroy()");

        mPlayer.stop();

        super.onDestroy();
    }

    public MusicService() {
    }

    //其他对象通过bindService方法通知该Service时该方法被调用
    @Override
    public IBinder onBind(Intent intent) {
        Toast.makeText(this, "MusicSevice onBind()"
                , Toast.LENGTH_SHORT).show();
        Log.e(TAG, "MusicService onBind()");

        mPlayer.start();

        return null;

    }

    //其它对象通过unbindService方法通知该Service时该方法被调用
    @Override
    public void unbindService(ServiceConnection conn) {
        Toast.makeText(this, "MusicSevice onUnbind()"
                , Toast.LENGTH_SHORT).show();
        Log.e(TAG, "MusicService onUnbind()");

        mPlayer.stop();
        super.unbindService(conn);
    }
}
